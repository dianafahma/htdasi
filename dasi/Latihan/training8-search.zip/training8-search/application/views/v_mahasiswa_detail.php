<table border="1" align="center">
<tr bgcolor="#0033ff">
	<td>NIM</td>
	<td><?php echo $row_data->nim; ?></td>
</tr>
<tr>
	<td>NAMA</td>
	<td><?php echo $row_data->nama; ?></td>
</tr>
<tr>
	<td>UMUR</td>
	<td><?php echo $row_data->umur; ?></td>
</tr>

</table>

