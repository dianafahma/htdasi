<br>
<?php
echo "Ini berita ..................... jadi tolong dilihat.";
?>
<br>
<br>
