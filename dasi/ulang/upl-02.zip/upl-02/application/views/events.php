<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Events - Summer Camp Website Template</title>
	<link rel="stylesheet" href="<?php echo base_url().'aset/css/style.css'?>" type="text/css">
</head>
<body>
	<div class="header">
		<div>
		<a href="<?php echo base_url().'index.php/c_camp/view_index'?>" id="logo"><img src="<?php echo base_url().'aset/images/logo.png'?>" alt="logo"></a>
			<ul>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_index'?>"><span>H</span>ome</a>
				</li>
				<li >
					<a href=""<?php echo base_url().'index.php/c_camp/view_about'?>""><span>A</span>bout</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_programs'?>"><span>P</span>rograms</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_blog'?>"><span>B</span>log</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_staff'?>"><span>S</span>taff</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_contact'?>"><span>C</span>ontact</a>
				</li>
			</ul>
			<div>
				<p>
					<span>C</span>amp <span>S</span>tarts <span>I</span>n: <span><span>228</span></span> <span>D</span>ays
				</p>
			</div>
		</div>
	</div>
	<div class="body">
		<div>
			<div>
				<div>
					<div class="events">
						<h2>UPCOMING EVENTS</h2>
						<div class="first">
							<h3>This is just a place holder</h3>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free. You can replace all this text with your own text.
							</p>
							<p>
								You can remove any link to our website from this website template, you're free to use this website template without linking back to us.
							</p>
							<p>
								If you're having problems editing this website template, then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forums/">Forums</a>.
							</p>
							<p>
								Morbi commodo sem imperdiet magna imperdiet auctor. Vestibulum tempus ullamcorper scelerisque. Pellentesque accumsan porttitor diam, id sagittis sem pulvinar in. Donec viverra, elit at rutrum rutrum, magna velit sagittis nunc, sed sagittis tellus nulla vel urna. Nunc posuere porttitor purus in semper. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi pretium iaculis tincidunt. Aenean scelerisque molestie urna a fermentum.
							</p>
							<p>
								Donec dictum lacus id leo egestas lacinia. Cras nec velit odio, vitae tincidunt lectus. Morbi quis lacinia ligula. Morbi lacus nisl, feugiat quis tristique a, dignissim pellentesque augue. Quisque id velit nibh. Nunc ut augue quis est hendrerit consectetur quis a turpis. Nulla quis sodales nisi.
							</p>
							<p>
								Donec vitae ligula a mi condimentum fermentum. Duis pulvinar leo in est sodales ac malesuada neque dapibus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
							</p>
						</div>
						<div>
							<ul>
								<li>
									<div>
										<span>11/07/2011</span>
										<p>
											Phasellus parea ut di tincidunt blandit nisi ut pellentesque.
										</p>
									</div>
								</li>
								<li>
									<div>
										<span>11/03/2011</span>
										<p>
											Donec dictum semper augue, ut consectetur magna.
										</p>
									</div>
								</li>
								<li>
									<div>
										<span>10/27/2011</span>
										<p>
											Cum sociis natoque penatibus et magnis dis.
										</p>
									</div>
								</li>
								<li>
									<div>
										<span>10/25/2011</span>
										<p>
											Morbi commodo sem imperdiet magna imperdiet auctor.
										</p>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer">
		<div>
			<div>
				<h3>NEWSLETTER</h3>
				<p>
					Nulla porttitor vulputate elit, trist ique malesuada sem.
				</p>
				<form action="index.php">
					<input type="text" value="Email Address" onblur="this.value=!this.value?'Email Address':this.value;" onfocus="this.select()" onclick="this.value='';">
					<input type="submit" value="Get">
				</form>
			</div>
			<div>
				<h4>LATEST BLOG</h4>
				<ul>
					<li>
						<p>
							<a href="blog.php">Phasellus parea ut di tincidunt blandit nisi ut pellentesque.</a>
						</p>
						<span>11/07/2011</span>
					</li>
					<li>
						<p>
							<a href="blog.php">Donec dictum semper augue, ut consectetur magna posuere eget.</a>
						</p>
						<span>11/03/2011</span>
					</li>
					<li>
						<p>
							<a href="blog.php">Cum sociis natoque penatibus et magnis dis parturient.</a>
						</p>
						<span>11/27/2011</span>
					</li>
				</ul>
			</div>
			<div class="connect">
				<h4>FOLLOW US:</h4>
				<a href="http://freewebsitetemplates.com/go/facebook/" class="facebook">Facebook</a> <a href="http://freewebsitetemplates.com/go/twitter/" class="twitter">Twitter</a> <a href="http://freewebsitetemplates.com/go/googleplus/" class="google">Google+</a>
			</div>
		</div>
		<div>
			<p>
				Summer Camp &#169; 2011 | All Rights Reserved
			</p>
		</div>
	</div>
</body>
</html>