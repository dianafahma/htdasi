<DOCTYPE html>
<html>
<head>
</head>
<body>
ndaskfhalsdkfnla
<?php echo anchor ('c_camp/view_about','About')?>

</body>
</html>