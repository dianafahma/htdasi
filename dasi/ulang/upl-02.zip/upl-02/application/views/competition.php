<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Competition - Summer Camp Website Template</title>
	<link rel="stylesheet" href="<?php echo base_url().'aset/css/style.css'?>" type="text/css">
</head>
<body>
	<div class="header">
		<div>
			<a href="<?php echo base_url().'index.php/c_camp/view_index'?>" id="logo"><img src="<?php echo base_url().'aset/images/logo.png'?>" alt="logo"></a>
			<ul>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_index'?>"><span>H</span>ome</a>
				</li>
				<li >
					<a href="<?php echo base_url().'index.php/c_camp/view_about'?>"><span>A</span>bout</a>
				</li>
				<li class="selected">
					<a href="<?php echo base_url().'index.php/c_camp/view_programs'?>"><span>P</span>rograms</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_blog'?>"><span>B</span>log</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_staff'?>"><span>S</span>taff</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_contact'?>"><span>C</span>ontact</a>
				</li>
			</ul>
			<div>
				<p>
					<span>C</span>amp <span>S</span>tarts <span>I</span>n: <span><span>228</span></span> <span>D</span>ays
				</p>
			</div>
		</div>
	</div>
	<div class="body">
		<div>
			<div>
				<div>
					<div class="competition">
						<h2>SUMMER CAMP PROGRAMS</h2>
						<div class="first">
							<ul>
								<li >
									<a href="<?php echo base_url().'index.php/c_camp/view_programs'?>">OUR MISSION</a>
								</li>
								<li class="selected">
									<a href="<?php echo base_url().'index.php/c_camp/view_competition'?>">TEAM COMPETITION</a>
								</li>
								<li>
									<a href="<?php echo base_url().'index.php/c_camp/view_activities'?>">ACTIVITIES</a>
								</li>
							</ul>
						</div>
						<div>
							<h3>We Have More Templates for You</h3>
							<p>
								Looking for more templates? Just browse through all our <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> and find what you're looking for. But if you don't find any website template you can use, you can try our <a href="http://www.freewebsitetemplates.com/freewebdesign/">Free Web Design</a> service and tell us all about it. Maybe you're looking for something different, something special. And we love the challenge of doing something different and something special.
							</p>
							<h3 class="title">This is just a place holder</h3>
							<ul>
								<li>
									<p>
										Aliquam ad seconsi consequat massa a lectus.
									</p>
								</li>
								<li>
									<p>
										Vestibulum portitor magna cumla massa a lectus.
									</p>
								</li>
								<li>
									<p>
										Cras lorem ipsum congue ante nec orci volutpat non.
									</p>
								</li>
								<li>
									<p>
										Donec balnoa gongaga congue ante nec orci volutpat non.
									</p>
								</li>
							</ul>
							<h3>This is just a place holder</h3>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free. You can replace all this text with your own text.
							</p>
							<p>
								You can remove any link to our website from this website template, you're free to use this website template without linking back to us
							</p>
							<p>
								If you're having problems editing this website template, then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forums/">Forums</a>.
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer">
		<div>
			<div>
				<h3>NEWSLETTER</h3>
				<p>
					Nulla porttitor vulputate elit, trist ique malesuada sem.
				</p>
				<form action="index.html">
					<input type="text" value="Email Address" onblur="this.value=!this.value?'Email Address':this.value;" onfocus="this.select()" onclick="this.value='';">
					<input type="submit" value="Get">
				</form>
			</div>
			<div>
				<h4>LATEST BLOG</h4>
				<ul>
					<li>
						<p>
							<a href="blog.html">Phasellus parea ut di tincidunt blandit nisi ut pellentesque.</a>
						</p>
						<span>11/07/2011</span>
					</li>
					<li>
						<p>
							<a href="blog.html">Donec dictum semper augue, ut consectetur magna posuere eget.</a>
						</p>
						<span>11/03/2011</span>
					</li>
					<li>
						<p>
							<a href="blog.html">Cum sociis natoque penatibus et magnis dis parturient.</a>
						</p>
						<span>11/27/2011</span>
					</li>
				</ul>
			</div>
			<div class="connect">
				<h4>FOLLOW US:</h4>
				<a href="http://freewebsitetemplates.com/go/facebook/" class="facebook">Facebook</a> <a href="http://freewebsitetemplates.com/go/twitter/" class="twitter">Twitter</a> <a href="http://freewebsitetemplates.com/go/googleplus/" class="google">Google+</a>
			</div>
		</div>
		<div>
			<p>
				Summer Camp &#169; 2011 | All Rights Reserved
			</p>
		</div>
	</div>
</body>

</html>