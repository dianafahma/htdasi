<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Staff - Summer Camp Website Template</title>
	<link rel="stylesheet" href="<?php echo base_url().'aset/css/style.css'?>" type="text/css">
</head>
<body>
	<div class="header">
		<div>
			<a href="<?php echo base_url().'index.php/c_camp/view_index'?>" id="logo"><img src="<?php echo base_url().'aset/images/logo.png'?>" alt="logo"></a>
			<ul>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_index'?>"><span>H</span>ome</a>
				</li>
				<li >
					<a href=""<?php echo base_url().'index.php/c_camp/view_about'?>""><span>A</span>bout</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_programs'?>"><span>P</span>rograms</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_blog'?>"><span>B</span>log</a>
				</li>
				<li class="selected">
					<a href="<?php echo base_url().'index.php/c_camp/view_staff'?>"><span>S</span>taff</a>
				</li>
				<li>
					<a href="<?php echo base_url().'index.php/c_camp/view_contact'?>"><span>C</span>ontact</a>
				</li>
			</ul>
			<div>
				<p>
					<span>C</span>amp <span>S</span>tarts <span>I</span>n: <span><span>228</span></span> <span>D</span>ays
				</p>
			</div>
		</div>
	</div>
	<div class="body">
		<div>
			<div>
				<div>
					<div class="staff">
						<h2>SUMMER CAMP STAFF</h2>
						<div class="first">
							<h3><span>S</span>taff <span>L</span>ogin</h3>
							<form action="index.php">
								<input type="text" value="Username" onblur="this.value=!this.value?'Username':this.value;" onfocus="this.select()" onclick="this.value='';">
								<input type="password" value="">
								<a href="#">Forgot your password?</a>
								<input type="submit" id="submit" value="Login">
							</form>
						</div>
						<div>
							<h3>This is just a place holder</h3>
							<p>
								Donec vel arcu ante, accumsan imperdiet eros. Sed varius justo eget arcu ornare commodo. Nulla urna odio, elementum id pretium quis, viverra non nibh. Suspendisse egestas placerat felis in adipiscing. Mauris nisl risus, rhoncus non ultricies a, bibendum eget erat.
							</p>
							<h3>This is just a place holder</h3>
							<ul>
								<li>
									<p>
										Donec vitae ligula a mi condimentum fermentum. Duis pulvinar leo in est sodales ac malesuada neque dapibus.
									</p>
								</li>
								<li>
									<p>
										Morbi commodo sem imperdiet magna imperdiet auctor. Vestibulum tempus.
									</p>
								</li>
								<li>
									<p>
										Duis nibh lacus malesuada in dignissim ac aliquam eu ipsum. Maecenas libero nulla consectetur.
									</p>
								</li>
							</ul>
							<h3>This is just a place holder</h3>
							<p>
								Nullam sodales convallis sollicitudin. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris rhoncus laoreet lectus, ac porttitor ligula faucibus sed. Aliquam consequat massa a lectus euismod eu accumsan quam semper.
							</p>
							<p>
								Cras congue ante nec orci volutpat non aliquet nisl interdum. Integer gravida, felis eget posuere pellentesque, ligula libero porta lacus, nec ultrices arcu lectus et metus. Aenean quis tortor neque, in accumsan erat. Aliquam diam massa dignissim a ultricies sagittis.
							</p>
							<a href="<?php echo base_url().'index.php/c_camp/view_application'?>">Apply Now</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer">
		<div>
			<div>
				<h3>NEWSLETTER</h3>
				<p>
					Nulla porttitor vulputate elit, trist ique malesuada sem.
				</p>
				<form action="index.php">
					<input type="text" value="Email Address" onblur="this.value=!this.value?'Email Address':this.value;" onfocus="this.select()" onclick="this.value='';">
					<input type="submit" value="Get">
				</form>
			</div>
			<div>
				<h4>LATEST BLOG</h4>
				<ul>
					<li>
						<p>
							<a href="blog.php">Phasellus parea ut di tincidunt blandit nisi ut pellentesque.</a>
						</p>
						<span>11/07/2011</span>
					</li>
					<li>
						<p>
							<a href="blog.php">Donec dictum semper augue, ut consectetur magna posuere eget.</a>
						</p>
						<span>11/03/2011</span>
					</li>
					<li>
						<p>
							<a href="blog.php">Cum sociis natoque penatibus et magnis dis parturient.</a>
						</p>
						<span>11/27/2011</span>
					</li>
				</ul>
			</div>
			<div class="connect">
				<h4>FOLLOW US:</h4>
				<a href="http://freewebsitetemplates.com/go/facebook/" class="facebook">Facebook</a> <a href="http://freewebsitetemplates.com/go/twitter/" class="twitter">Twitter</a> <a href="http://freewebsitetemplates.com/go/googleplus/" class="google">Google+</a>
			</div>
		</div>
		<div>
			<p>
				Summer Camp &#169; 2011 | All Rights Reserved
			</p>
		</div>
	</div>
</body>
</html>