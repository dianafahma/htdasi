<!DOCTYPE html>
<html>
<head>
	<meta lang="en" />
	<title>Login Form</title>
</head>
<body>
	<div></div>
	<label for="username">Username</label>
	<input type="text" name="username" placeholder="Username" required/><br/>
	<label for="password" >Password </label>
	<input type="password" name="password" placeholder="Password" required/><br/>
	<button type="submit" value="Login" />
<footer></footer>
</body>
</html>
